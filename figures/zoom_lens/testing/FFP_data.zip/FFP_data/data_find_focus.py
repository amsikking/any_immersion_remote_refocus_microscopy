import numpy as np
from tifffile import imread, imwrite
from scipy.ndimage import gaussian_filter

config_f_mm = np.linspace(132.5, 150, 8)
z_steps_um = np.linspace(0, 1000, 41)
camera_px_um = 6.5

x_px, y_px, z_um = [], [], []

for f_mm in config_f_mm:
    filename = 'data_%0.1f.tif'%f_mm
    print('reading:', filename)
    data = imread(filename)
    smooth_data = gaussian_filter(data, sigma=1)
    imwrite('smooth_data_%0.1f.tif'%f_mm, smooth_data)
    focus_index = np.unravel_index(np.argmax(smooth_data), smooth_data.shape)
    x_px.append(focus_index[2])
    y_px.append(focus_index[1])
    z_um.append(z_steps_um[focus_index[0]])

print('\nfocus location:')
print('f_mm:', config_f_mm)
print('x_px:', x_px)
print('y_px:', y_px)
print('z_um:', z_um)

max_x_um = (max(x_px) - min(x_px)) * camera_px_um
max_y_um = (max(y_px) - min(y_px)) * camera_px_um
max_xy_um = (max_x_um**2 + max_y_um**2)**0.5

print('\nmax displacement (um):')
print('x  =', max_x_um)
print('y  =', max_y_um)
print('xy =', max_xy_um)
print('z  =', (max(z_um) - min(z_um)))
