import numpy as np
from tifffile import imread, imwrite

# This script was used to crop out the central portion of the image from
# the raw camera images and make the data size more acceptable

config_f_mm = np.linspace(132.5, 150, 8)

for f_mm in config_f_mm:
    print('f_mm', f_mm)
    data = imread('f_mm_%0.1f.tif'%f_mm)[:, 420:620, 596:796] # crop out focus
    imwrite('data_%0.1f.tif'%f_mm, data)
